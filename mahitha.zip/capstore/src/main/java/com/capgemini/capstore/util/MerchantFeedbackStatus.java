package com.capgemini.capstore.util;

public enum MerchantFeedbackStatus {
	NOT_FORWARDED, FORWARDED, RESPONDED;
}
