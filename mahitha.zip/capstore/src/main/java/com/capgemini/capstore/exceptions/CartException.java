package com.capgemini.capstore.exceptions;

@SuppressWarnings("serial")
public class CartException extends Exception {
	public CartException()
	{
		super();
	}
	public CartException(String msg)
	{
		super(msg);
	}

}
