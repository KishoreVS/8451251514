package com.capgemini.capstore.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "cap_revenue")

public class Revenue {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "rev_seq_gen")
	@SequenceGenerator(name = "rev_seq_gen", initialValue = 10000, sequenceName = "rev_seq")
	@Column(length = 20)
	private long invoiceId;
	private double previousRevenue;
	private double currentRevenue;
	
	
	public long getInvoiceId() {
		return invoiceId;
	}
	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}
	public double getPreviousRevenue() {
		return previousRevenue;
	}
	public void setPreviousRevenue(double previousRevenue) {
		this.previousRevenue = previousRevenue;
	}
	public double getCurrentRevenue() {
		return currentRevenue;
	}
	public void setCurrentRevenue(double currentRevenue) {
		this.currentRevenue = currentRevenue;
	}
	public Revenue(long invoiceId, double previousRevenue, double currentRevenue) {
		super();
		this.invoiceId = invoiceId;
		this.previousRevenue = previousRevenue;
		this.currentRevenue = currentRevenue;
	}
	

}
