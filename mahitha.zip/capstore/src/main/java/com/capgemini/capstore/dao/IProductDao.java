package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.Product;

public interface IProductDao extends  JpaRepository<Product,Integer> {
	

}
