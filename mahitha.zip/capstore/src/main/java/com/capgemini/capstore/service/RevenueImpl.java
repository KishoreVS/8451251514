package com.capgemini.capstore.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Invoice;
import com.capgemini.capstore.dao.IRevenue;

@Service
public class RevenueImpl implements IRevenueService{

	@Autowired
	IRevenue rev;
	
	@Override
	public double getDetails(long invoiceId) {
		Optional<Invoice> optional=rev.findById(invoiceId);
		Invoice invoice=optional.get();
		double amount=invoice.getFinalAmount();
		return amount;
		
			
		
		
	}

}
