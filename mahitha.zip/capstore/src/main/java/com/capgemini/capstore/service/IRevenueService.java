package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Invoice;

public interface IRevenueService {

	public double getDetails(long invoiceId);

}
