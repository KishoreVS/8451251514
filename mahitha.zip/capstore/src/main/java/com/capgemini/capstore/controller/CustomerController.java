package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.service.ICustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	ICustomerService customerservice;
	
	@PostMapping(value="/create")
	public Customer createAccount(@RequestBody Customer customer)
	{
		return customerservice.createAccount(customer);
	}
	
	@GetMapping(value="/getAccount/{customerId}")
	public Customer viewById(@PathVariable long customerId)
	{
		return customerservice.viewById(customerId);
	}
	
	@PutMapping(value="/changePassword/{customerId}/{oldPassword}/{newPassword}")
	public boolean changePassword(@PathVariable long customerId,@PathVariable String oldPassword,@PathVariable String newPassword,@RequestBody Customer customer) throws CapStoreException
	{
		return customerservice.changePassword(customerId,oldPassword,newPassword,customer);
	}
	
	
}
